﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dorm_and_Meal_Plan_Calculator
{
    class MealPlan
    {
        private string _name;
        private int _cost;

        public MealPlan()
        {
            _name = " ";
            _cost = 0;
        }
        public MealPlan(string Name, int Cost)
        {
            _name = Name;
            _cost = Cost;
        }
        public string Name
        {
            get { return _name; }
            set { _name = Name; }
        }
        public int Cost
        {
            get { return _cost; }
            set { _cost = Cost; }
        }
    }
}
