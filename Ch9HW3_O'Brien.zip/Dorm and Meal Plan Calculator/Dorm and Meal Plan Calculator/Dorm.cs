﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dorm_and_Meal_Plan_Calculator
{
    class Dorm
    {
        private string _name;
        private int _cost;

        public Dorm()
        {
            _name = " ";
            _cost = 0;
        }
        public Dorm(string name, int cost)
        {
            _name = name;
            _cost = cost;
        }
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        public int Cost
        {
            get { return _cost; }
            set { _cost = value; }
        }
    }
}
