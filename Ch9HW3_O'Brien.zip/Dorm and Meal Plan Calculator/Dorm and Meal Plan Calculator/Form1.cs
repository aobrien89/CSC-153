﻿/**
* 05/13/2018
* CSC 153
* Anthony O'Brien
* Calculates costs of dorm and meal plans.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dorm_and_Meal_Plan_Calculator
{
    public partial class Form1 : Form
    {
        Dorm allen = new Dorm("Allen Hall", 1500);
        Dorm pike = new Dorm("Pike Hall", 1600);
        Dorm farthing = new Dorm("Farthing Hall", 1800);
        Dorm university = new Dorm("University Suites", 2500);

        MealPlan sevenMeals = new MealPlan("7 meals per week", 600);
        MealPlan fourteenMeals = new MealPlan("14 meals per week", 1200);
        MealPlan unlimited = new MealPlan("Unlimited meals", 1700);

        public Form1()
        {
            InitializeComponent();
                                              
        }
        private void calculateButton_Click(object sender, EventArgs e)
        {
            Form2 costsForm = new Form2();
            if (allenRadioButton.Checked)
            {
                costsForm.dormLabel.Text = allen.Cost.ToString("c");
            }
            else if(pikeRadioButton.Checked)
            {
                costsForm.dormLabel.Text = pike.Cost.ToString("c");
            }
            else if (farthingRadioButton.Checked)
            {
                costsForm.dormLabel.Text = farthing.Cost.ToString("c");
            }
            else if (universityRadioButton.Checked)
            {
                costsForm.dormLabel.Text = university.Cost.ToString("c");
            }

            if (meals7RadioButton.Checked)
            {
                costsForm.mealLabel.Text = sevenMeals.Cost.ToString("c");
            }
            else if (meals14RadioButton.Checked)
            {
                costsForm.mealLabel.Text = fourteenMeals.Cost.ToString("c");
            }
            else if (unlimitedRadioButton.Checked)
            {
                costsForm.mealLabel.Text = unlimited.Cost.ToString("c");
            }

            int number = int.Parse(costsForm.dormLabel.Text, System.Globalization.NumberStyles.Currency);
            int number2= int.Parse(costsForm.mealLabel.Text, System.Globalization.NumberStyles.Currency);
            int tot = number + number2;
            costsForm.totalLabel.Text = tot.ToString("c");

            costsForm.ShowDialog();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
