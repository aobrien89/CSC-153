﻿namespace Dorm_and_Meal_Plan_Calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.allenRadioButton = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.calculateButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.pikeRadioButton = new System.Windows.Forms.RadioButton();
            this.farthingRadioButton = new System.Windows.Forms.RadioButton();
            this.universityRadioButton = new System.Windows.Forms.RadioButton();
            this.meals14RadioButton = new System.Windows.Forms.RadioButton();
            this.unlimitedRadioButton = new System.Windows.Forms.RadioButton();
            this.meals7RadioButton = new System.Windows.Forms.RadioButton();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.universityRadioButton);
            this.groupBox1.Controls.Add(this.farthingRadioButton);
            this.groupBox1.Controls.Add(this.pikeRadioButton);
            this.groupBox1.Controls.Add(this.allenRadioButton);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(151, 123);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Dorms";
            // 
            // allenRadioButton
            // 
            this.allenRadioButton.AutoSize = true;
            this.allenRadioButton.Location = new System.Drawing.Point(6, 19);
            this.allenRadioButton.Name = "allenRadioButton";
            this.allenRadioButton.Size = new System.Drawing.Size(108, 17);
            this.allenRadioButton.TabIndex = 0;
            this.allenRadioButton.TabStop = true;
            this.allenRadioButton.Text = "Allen Hall: $1,500";
            this.allenRadioButton.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.meals7RadioButton);
            this.groupBox2.Controls.Add(this.unlimitedRadioButton);
            this.groupBox2.Controls.Add(this.meals14RadioButton);
            this.groupBox2.Location = new System.Drawing.Point(169, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(169, 123);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Meal Plans";
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(49, 141);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 23);
            this.calculateButton.TabIndex = 1;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(206, 141);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // pikeRadioButton
            // 
            this.pikeRadioButton.AutoSize = true;
            this.pikeRadioButton.Location = new System.Drawing.Point(6, 42);
            this.pikeRadioButton.Name = "pikeRadioButton";
            this.pikeRadioButton.Size = new System.Drawing.Size(106, 17);
            this.pikeRadioButton.TabIndex = 1;
            this.pikeRadioButton.TabStop = true;
            this.pikeRadioButton.Text = "Pike Hall: $1,600";
            this.pikeRadioButton.UseVisualStyleBackColor = true;
            // 
            // farthingRadioButton
            // 
            this.farthingRadioButton.AutoSize = true;
            this.farthingRadioButton.Location = new System.Drawing.Point(6, 65);
            this.farthingRadioButton.Name = "farthingRadioButton";
            this.farthingRadioButton.Size = new System.Drawing.Size(123, 17);
            this.farthingRadioButton.TabIndex = 2;
            this.farthingRadioButton.TabStop = true;
            this.farthingRadioButton.Text = "Farthing Hall: $1,800";
            this.farthingRadioButton.UseVisualStyleBackColor = true;
            // 
            // universityRadioButton
            // 
            this.universityRadioButton.AutoSize = true;
            this.universityRadioButton.Location = new System.Drawing.Point(6, 88);
            this.universityRadioButton.Name = "universityRadioButton";
            this.universityRadioButton.Size = new System.Drawing.Size(142, 17);
            this.universityRadioButton.TabIndex = 3;
            this.universityRadioButton.TabStop = true;
            this.universityRadioButton.Text = "University Suites: $2,500";
            this.universityRadioButton.UseVisualStyleBackColor = true;
            // 
            // meals14RadioButton
            // 
            this.meals14RadioButton.AutoSize = true;
            this.meals14RadioButton.Location = new System.Drawing.Point(6, 42);
            this.meals14RadioButton.Name = "meals14RadioButton";
            this.meals14RadioButton.Size = new System.Drawing.Size(153, 17);
            this.meals14RadioButton.TabIndex = 1;
            this.meals14RadioButton.TabStop = true;
            this.meals14RadioButton.Text = "14 meals per week: $1,200";
            this.meals14RadioButton.UseVisualStyleBackColor = true;
            // 
            // unlimitedRadioButton
            // 
            this.unlimitedRadioButton.AutoSize = true;
            this.unlimitedRadioButton.Location = new System.Drawing.Point(6, 65);
            this.unlimitedRadioButton.Name = "unlimitedRadioButton";
            this.unlimitedRadioButton.Size = new System.Drawing.Size(137, 17);
            this.unlimitedRadioButton.TabIndex = 2;
            this.unlimitedRadioButton.TabStop = true;
            this.unlimitedRadioButton.Text = "Unlimited meals: $1,700";
            this.unlimitedRadioButton.UseVisualStyleBackColor = true;
            // 
            // meals7RadioButton
            // 
            this.meals7RadioButton.AutoSize = true;
            this.meals7RadioButton.Location = new System.Drawing.Point(6, 19);
            this.meals7RadioButton.Name = "meals7RadioButton";
            this.meals7RadioButton.Size = new System.Drawing.Size(138, 17);
            this.meals7RadioButton.TabIndex = 3;
            this.meals7RadioButton.TabStop = true;
            this.meals7RadioButton.Text = "7 meals per week: $600";
            this.meals7RadioButton.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(352, 187);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Dorm and Meal Calculator";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.RadioButton allenRadioButton;
        private System.Windows.Forms.RadioButton universityRadioButton;
        private System.Windows.Forms.RadioButton farthingRadioButton;
        private System.Windows.Forms.RadioButton pikeRadioButton;
        private System.Windows.Forms.RadioButton unlimitedRadioButton;
        private System.Windows.Forms.RadioButton meals14RadioButton;
        private System.Windows.Forms.RadioButton meals7RadioButton;
    }
}

