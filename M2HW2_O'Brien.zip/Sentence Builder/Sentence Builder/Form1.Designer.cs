﻿namespace Sentence_Builder
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.upperAButton = new System.Windows.Forms.Button();
            this.lowerAButton = new System.Windows.Forms.Button();
            this.upperAnButton = new System.Windows.Forms.Button();
            this.lowerAnButton = new System.Windows.Forms.Button();
            this.upperTheButton = new System.Windows.Forms.Button();
            this.lowerTheButton = new System.Windows.Forms.Button();
            this.manButton = new System.Windows.Forms.Button();
            this.womanButton = new System.Windows.Forms.Button();
            this.dogButton = new System.Windows.Forms.Button();
            this.catButton = new System.Windows.Forms.Button();
            this.carButton = new System.Windows.Forms.Button();
            this.bicycleButton = new System.Windows.Forms.Button();
            this.beautifulButton = new System.Windows.Forms.Button();
            this.bigButton = new System.Windows.Forms.Button();
            this.smallButton = new System.Windows.Forms.Button();
            this.strangeButton = new System.Windows.Forms.Button();
            this.lookedAtButton = new System.Windows.Forms.Button();
            this.rodeButton = new System.Windows.Forms.Button();
            this.spokeToButton = new System.Windows.Forms.Button();
            this.laughedAtButton = new System.Windows.Forms.Button();
            this.droveButton = new System.Windows.Forms.Button();
            this.spaceButton = new System.Windows.Forms.Button();
            this.periodButton = new System.Windows.Forms.Button();
            this.exclaimationButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.sentenceTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // upperAButton
            // 
            this.upperAButton.Location = new System.Drawing.Point(123, 36);
            this.upperAButton.Name = "upperAButton";
            this.upperAButton.Size = new System.Drawing.Size(26, 23);
            this.upperAButton.TabIndex = 0;
            this.upperAButton.Text = "A";
            this.upperAButton.UseVisualStyleBackColor = true;
            this.upperAButton.Click += new System.EventHandler(this.upperAButton_Click);
            // 
            // lowerAButton
            // 
            this.lowerAButton.Location = new System.Drawing.Point(155, 36);
            this.lowerAButton.Name = "lowerAButton";
            this.lowerAButton.Size = new System.Drawing.Size(28, 23);
            this.lowerAButton.TabIndex = 1;
            this.lowerAButton.Text = "a";
            this.lowerAButton.UseVisualStyleBackColor = true;
            this.lowerAButton.Click += new System.EventHandler(this.lowerAButton_Click);
            // 
            // upperAnButton
            // 
            this.upperAnButton.Location = new System.Drawing.Point(189, 36);
            this.upperAnButton.Name = "upperAnButton";
            this.upperAnButton.Size = new System.Drawing.Size(31, 23);
            this.upperAnButton.TabIndex = 2;
            this.upperAnButton.Text = "An";
            this.upperAnButton.UseVisualStyleBackColor = true;
            this.upperAnButton.Click += new System.EventHandler(this.upperAnButton_Click);
            // 
            // lowerAnButton
            // 
            this.lowerAnButton.Location = new System.Drawing.Point(226, 36);
            this.lowerAnButton.Name = "lowerAnButton";
            this.lowerAnButton.Size = new System.Drawing.Size(32, 23);
            this.lowerAnButton.TabIndex = 3;
            this.lowerAnButton.Text = "an";
            this.lowerAnButton.UseVisualStyleBackColor = true;
            this.lowerAnButton.Click += new System.EventHandler(this.lowerAnButton_Click);
            // 
            // upperTheButton
            // 
            this.upperTheButton.Location = new System.Drawing.Point(264, 36);
            this.upperTheButton.Name = "upperTheButton";
            this.upperTheButton.Size = new System.Drawing.Size(42, 23);
            this.upperTheButton.TabIndex = 4;
            this.upperTheButton.Text = "The";
            this.upperTheButton.UseVisualStyleBackColor = true;
            this.upperTheButton.Click += new System.EventHandler(this.upperTheButton_Click);
            // 
            // lowerTheButton
            // 
            this.lowerTheButton.Location = new System.Drawing.Point(312, 36);
            this.lowerTheButton.Name = "lowerTheButton";
            this.lowerTheButton.Size = new System.Drawing.Size(36, 23);
            this.lowerTheButton.TabIndex = 5;
            this.lowerTheButton.Text = "the";
            this.lowerTheButton.UseVisualStyleBackColor = true;
            this.lowerTheButton.Click += new System.EventHandler(this.lowerTheButton_Click);
            // 
            // manButton
            // 
            this.manButton.Location = new System.Drawing.Point(83, 65);
            this.manButton.Name = "manButton";
            this.manButton.Size = new System.Drawing.Size(41, 23);
            this.manButton.TabIndex = 6;
            this.manButton.Text = "man";
            this.manButton.UseVisualStyleBackColor = true;
            this.manButton.Click += new System.EventHandler(this.manButton_Click);
            // 
            // womanButton
            // 
            this.womanButton.Location = new System.Drawing.Point(130, 65);
            this.womanButton.Name = "womanButton";
            this.womanButton.Size = new System.Drawing.Size(58, 23);
            this.womanButton.TabIndex = 7;
            this.womanButton.Text = "woman";
            this.womanButton.UseVisualStyleBackColor = true;
            this.womanButton.Click += new System.EventHandler(this.womanButton_Click);
            // 
            // dogButton
            // 
            this.dogButton.Location = new System.Drawing.Point(194, 65);
            this.dogButton.Name = "dogButton";
            this.dogButton.Size = new System.Drawing.Size(45, 23);
            this.dogButton.TabIndex = 8;
            this.dogButton.Text = "dog";
            this.dogButton.UseVisualStyleBackColor = true;
            this.dogButton.Click += new System.EventHandler(this.dogButton_Click);
            // 
            // catButton
            // 
            this.catButton.Location = new System.Drawing.Point(245, 65);
            this.catButton.Name = "catButton";
            this.catButton.Size = new System.Drawing.Size(34, 23);
            this.catButton.TabIndex = 9;
            this.catButton.Text = "cat";
            this.catButton.UseVisualStyleBackColor = true;
            this.catButton.Click += new System.EventHandler(this.catButton_Click);
            // 
            // carButton
            // 
            this.carButton.Location = new System.Drawing.Point(285, 65);
            this.carButton.Name = "carButton";
            this.carButton.Size = new System.Drawing.Size(35, 23);
            this.carButton.TabIndex = 10;
            this.carButton.Text = "car";
            this.carButton.UseVisualStyleBackColor = true;
            this.carButton.Click += new System.EventHandler(this.carButton_Click);
            // 
            // bicycleButton
            // 
            this.bicycleButton.Location = new System.Drawing.Point(326, 65);
            this.bicycleButton.Name = "bicycleButton";
            this.bicycleButton.Size = new System.Drawing.Size(60, 23);
            this.bicycleButton.TabIndex = 11;
            this.bicycleButton.Text = "bicycle";
            this.bicycleButton.UseVisualStyleBackColor = true;
            this.bicycleButton.Click += new System.EventHandler(this.bicycleButton_Click);
            // 
            // beautifulButton
            // 
            this.beautifulButton.Location = new System.Drawing.Point(93, 94);
            this.beautifulButton.Name = "beautifulButton";
            this.beautifulButton.Size = new System.Drawing.Size(65, 23);
            this.beautifulButton.TabIndex = 12;
            this.beautifulButton.Text = "beautiful";
            this.beautifulButton.UseVisualStyleBackColor = true;
            this.beautifulButton.Click += new System.EventHandler(this.beautifulButton_Click);
            // 
            // bigButton
            // 
            this.bigButton.Location = new System.Drawing.Point(164, 94);
            this.bigButton.Name = "bigButton";
            this.bigButton.Size = new System.Drawing.Size(42, 23);
            this.bigButton.TabIndex = 13;
            this.bigButton.Text = "big";
            this.bigButton.UseVisualStyleBackColor = true;
            this.bigButton.Click += new System.EventHandler(this.bigButton_Click);
            // 
            // smallButton
            // 
            this.smallButton.Location = new System.Drawing.Point(212, 94);
            this.smallButton.Name = "smallButton";
            this.smallButton.Size = new System.Drawing.Size(55, 23);
            this.smallButton.TabIndex = 14;
            this.smallButton.Text = "small";
            this.smallButton.UseVisualStyleBackColor = true;
            this.smallButton.Click += new System.EventHandler(this.smallButton_Click);
            // 
            // strangeButton
            // 
            this.strangeButton.Location = new System.Drawing.Point(273, 94);
            this.strangeButton.Name = "strangeButton";
            this.strangeButton.Size = new System.Drawing.Size(75, 23);
            this.strangeButton.TabIndex = 15;
            this.strangeButton.Text = "strange";
            this.strangeButton.UseVisualStyleBackColor = true;
            this.strangeButton.Click += new System.EventHandler(this.strangeButton_Click);
            // 
            // lookedAtButton
            // 
            this.lookedAtButton.Location = new System.Drawing.Point(42, 123);
            this.lookedAtButton.Name = "lookedAtButton";
            this.lookedAtButton.Size = new System.Drawing.Size(68, 23);
            this.lookedAtButton.TabIndex = 16;
            this.lookedAtButton.Text = "looked at";
            this.lookedAtButton.UseVisualStyleBackColor = true;
            this.lookedAtButton.Click += new System.EventHandler(this.lookedAtButton_Click);
            // 
            // rodeButton
            // 
            this.rodeButton.Location = new System.Drawing.Point(116, 123);
            this.rodeButton.Name = "rodeButton";
            this.rodeButton.Size = new System.Drawing.Size(42, 23);
            this.rodeButton.TabIndex = 17;
            this.rodeButton.Text = "rode";
            this.rodeButton.UseVisualStyleBackColor = true;
            this.rodeButton.Click += new System.EventHandler(this.rodeButton_Click);
            // 
            // spokeToButton
            // 
            this.spokeToButton.Location = new System.Drawing.Point(164, 123);
            this.spokeToButton.Name = "spokeToButton";
            this.spokeToButton.Size = new System.Drawing.Size(75, 23);
            this.spokeToButton.TabIndex = 18;
            this.spokeToButton.Text = "spoke to";
            this.spokeToButton.UseVisualStyleBackColor = true;
            this.spokeToButton.Click += new System.EventHandler(this.spokeToButton_Click);
            // 
            // laughedAtButton
            // 
            this.laughedAtButton.Location = new System.Drawing.Point(245, 123);
            this.laughedAtButton.Name = "laughedAtButton";
            this.laughedAtButton.Size = new System.Drawing.Size(75, 23);
            this.laughedAtButton.TabIndex = 19;
            this.laughedAtButton.Text = "laughed at";
            this.laughedAtButton.UseVisualStyleBackColor = true;
            this.laughedAtButton.Click += new System.EventHandler(this.laughedAtButton_Click);
            // 
            // droveButton
            // 
            this.droveButton.Location = new System.Drawing.Point(326, 123);
            this.droveButton.Name = "droveButton";
            this.droveButton.Size = new System.Drawing.Size(75, 23);
            this.droveButton.TabIndex = 20;
            this.droveButton.Text = "drove";
            this.droveButton.UseVisualStyleBackColor = true;
            this.droveButton.Click += new System.EventHandler(this.droveButton_Click);
            // 
            // spaceButton
            // 
            this.spaceButton.Location = new System.Drawing.Point(154, 152);
            this.spaceButton.Name = "spaceButton";
            this.spaceButton.Size = new System.Drawing.Size(75, 23);
            this.spaceButton.TabIndex = 21;
            this.spaceButton.Text = "(Space)";
            this.spaceButton.UseVisualStyleBackColor = true;
            this.spaceButton.Click += new System.EventHandler(this.spaceButton_Click);
            // 
            // periodButton
            // 
            this.periodButton.Location = new System.Drawing.Point(235, 152);
            this.periodButton.Name = "periodButton";
            this.periodButton.Size = new System.Drawing.Size(23, 23);
            this.periodButton.TabIndex = 22;
            this.periodButton.Text = ".";
            this.periodButton.UseVisualStyleBackColor = true;
            this.periodButton.Click += new System.EventHandler(this.periodButton_Click);
            // 
            // exclaimationButton
            // 
            this.exclaimationButton.Location = new System.Drawing.Point(264, 154);
            this.exclaimationButton.Name = "exclaimationButton";
            this.exclaimationButton.Size = new System.Drawing.Size(28, 23);
            this.exclaimationButton.TabIndex = 23;
            this.exclaimationButton.Text = "!";
            this.exclaimationButton.UseVisualStyleBackColor = true;
            this.exclaimationButton.Click += new System.EventHandler(this.exclaimationButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(93, 209);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 24;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(264, 209);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 25;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // sentenceTextBox
            // 
            this.sentenceTextBox.Location = new System.Drawing.Point(12, 183);
            this.sentenceTextBox.Name = "sentenceTextBox";
            this.sentenceTextBox.Size = new System.Drawing.Size(429, 20);
            this.sentenceTextBox.TabIndex = 26;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(453, 246);
            this.Controls.Add(this.sentenceTextBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.exclaimationButton);
            this.Controls.Add(this.periodButton);
            this.Controls.Add(this.spaceButton);
            this.Controls.Add(this.droveButton);
            this.Controls.Add(this.laughedAtButton);
            this.Controls.Add(this.spokeToButton);
            this.Controls.Add(this.rodeButton);
            this.Controls.Add(this.lookedAtButton);
            this.Controls.Add(this.strangeButton);
            this.Controls.Add(this.smallButton);
            this.Controls.Add(this.bigButton);
            this.Controls.Add(this.beautifulButton);
            this.Controls.Add(this.bicycleButton);
            this.Controls.Add(this.carButton);
            this.Controls.Add(this.catButton);
            this.Controls.Add(this.dogButton);
            this.Controls.Add(this.womanButton);
            this.Controls.Add(this.manButton);
            this.Controls.Add(this.lowerTheButton);
            this.Controls.Add(this.upperTheButton);
            this.Controls.Add(this.lowerAnButton);
            this.Controls.Add(this.upperAnButton);
            this.Controls.Add(this.lowerAButton);
            this.Controls.Add(this.upperAButton);
            this.Name = "Form1";
            this.Text = "Sentence Builder";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button upperAButton;
        private System.Windows.Forms.Button lowerAButton;
        private System.Windows.Forms.Button upperAnButton;
        private System.Windows.Forms.Button lowerAnButton;
        private System.Windows.Forms.Button upperTheButton;
        private System.Windows.Forms.Button lowerTheButton;
        private System.Windows.Forms.Button manButton;
        private System.Windows.Forms.Button womanButton;
        private System.Windows.Forms.Button dogButton;
        private System.Windows.Forms.Button catButton;
        private System.Windows.Forms.Button carButton;
        private System.Windows.Forms.Button bicycleButton;
        private System.Windows.Forms.Button beautifulButton;
        private System.Windows.Forms.Button bigButton;
        private System.Windows.Forms.Button smallButton;
        private System.Windows.Forms.Button strangeButton;
        private System.Windows.Forms.Button lookedAtButton;
        private System.Windows.Forms.Button rodeButton;
        private System.Windows.Forms.Button spokeToButton;
        private System.Windows.Forms.Button laughedAtButton;
        private System.Windows.Forms.Button droveButton;
        private System.Windows.Forms.Button spaceButton;
        private System.Windows.Forms.Button periodButton;
        private System.Windows.Forms.Button exclaimationButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.TextBox sentenceTextBox;
    }
}

