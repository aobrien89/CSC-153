﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sentence_Builder
{
    public partial class Form1 : Form
    {
        string output = "";
        public Form1()
        {
            InitializeComponent();
        }

        private void upperAButton_Click(object sender, EventArgs e)
        {
            output = "A";
            sentenceTextBox.Text += output;
        }

        private void lowerAButton_Click(object sender, EventArgs e)
        {
            output = "a";
            sentenceTextBox.Text += output;
        }

        private void upperAnButton_Click(object sender, EventArgs e)
        {
            output = "An";
            sentenceTextBox.Text += output;
        }

        private void lowerAnButton_Click(object sender, EventArgs e)
        {
            output = "an";
            sentenceTextBox.Text += output;
        }

        private void upperTheButton_Click(object sender, EventArgs e)
        {
            output = "The";
            sentenceTextBox.Text += output;
        }

        private void lowerTheButton_Click(object sender, EventArgs e)
        {
            output = "the";
            sentenceTextBox.Text += output;
        }

        private void manButton_Click(object sender, EventArgs e)
        {
            output = "man";
            sentenceTextBox.Text += output;
        }

        private void womanButton_Click(object sender, EventArgs e)
        {
            output = "woman";
            sentenceTextBox.Text += output;
        }

        private void dogButton_Click(object sender, EventArgs e)
        {
            output = "dog";
            sentenceTextBox.Text += output;
        }

        private void catButton_Click(object sender, EventArgs e)
        {
            output = "cat";
            sentenceTextBox.Text += output;
        }

        private void carButton_Click(object sender, EventArgs e)
        {
            output = "car";
            sentenceTextBox.Text += output;
        }

        private void bicycleButton_Click(object sender, EventArgs e)
        {
            output = "bicycle";
            sentenceTextBox.Text += output;
        }

        private void beautifulButton_Click(object sender, EventArgs e)
        {
            output = "beautiful";
            sentenceTextBox.Text += output;
        }

        private void bigButton_Click(object sender, EventArgs e)
        {
            output = "big";
            sentenceTextBox.Text += output;
        }

        private void smallButton_Click(object sender, EventArgs e)
        {
            output = "small";
            sentenceTextBox.Text += output;
        }

        private void strangeButton_Click(object sender, EventArgs e)
        {
            output = "strange";
            sentenceTextBox.Text += output;
        }

        private void lookedAtButton_Click(object sender, EventArgs e)
        {
            output = "looked at";
            sentenceTextBox.Text += output;
        }

        private void rodeButton_Click(object sender, EventArgs e)
        {
            output = "rode";
            sentenceTextBox.Text += output;
        }

        private void spokeToButton_Click(object sender, EventArgs e)
        {
            output = "spoke to";
            sentenceTextBox.Text += output;
        }

        private void laughedAtButton_Click(object sender, EventArgs e)
        {
            output = "laughed at";
            sentenceTextBox.Text += output;
        }

        private void droveButton_Click(object sender, EventArgs e)
        {
            output = "drove";
            sentenceTextBox.Text += output;
        }

        private void spaceButton_Click(object sender, EventArgs e)
        {
            output = " ";
            sentenceTextBox.Text += output;
        }

        private void periodButton_Click(object sender, EventArgs e)
        {
            output = ".";
            sentenceTextBox.Text += output;
        }

        private void exclaimationButton_Click(object sender, EventArgs e)
        {
            output = "!";
            sentenceTextBox.Text += output;
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            sentenceTextBox.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
