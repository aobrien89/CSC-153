﻿/**
* 03/22/2018
* CSC 153
* Anthony O'Brien
* random dice roll program.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dice_Simulator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void rollButton_Click(object sender, EventArgs e)
        {
            Random rand = new Random();

            int index = rand.Next(dieImageList.Images.Count);
            int index2 = rand.Next(dieImageList.Images.Count);

            die1PictureBox.Image = dieImageList.Images[index];
            die2PictureBox.Image = dieImageList.Images[index2];
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
