﻿
/**
* 02/01/2018
* CSC 153 0051
* Anthony O'Brien
* Displays cards and when clicked, displays their name.
*/
namespace Card_Identifer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.twoClubs = new System.Windows.Forms.PictureBox();
            this.eightDiamonds = new System.Windows.Forms.PictureBox();
            this.aceSpades = new System.Windows.Forms.PictureBox();
            this.joker = new System.Windows.Forms.PictureBox();
            this.kingSpades = new System.Windows.Forms.PictureBox();
            this.instructionsButton = new System.Windows.Forms.Label();
            this.cardName = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.twoClubs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eightDiamonds)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aceSpades)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.joker)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kingSpades)).BeginInit();
            this.SuspendLayout();
            // 
            // twoClubs
            // 
            this.twoClubs.Image = ((System.Drawing.Image)(resources.GetObject("twoClubs.Image")));
            this.twoClubs.Location = new System.Drawing.Point(12, 73);
            this.twoClubs.Name = "twoClubs";
            this.twoClubs.Size = new System.Drawing.Size(151, 220);
            this.twoClubs.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.twoClubs.TabIndex = 0;
            this.twoClubs.TabStop = false;
            this.twoClubs.Click += new System.EventHandler(this.twoClubs_Click);
            // 
            // eightDiamonds
            // 
            this.eightDiamonds.Image = ((System.Drawing.Image)(resources.GetObject("eightDiamonds.Image")));
            this.eightDiamonds.Location = new System.Drawing.Point(181, 73);
            this.eightDiamonds.Name = "eightDiamonds";
            this.eightDiamonds.Size = new System.Drawing.Size(150, 220);
            this.eightDiamonds.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.eightDiamonds.TabIndex = 1;
            this.eightDiamonds.TabStop = false;
            this.eightDiamonds.Click += new System.EventHandler(this.eightDiamonds_Click);
            // 
            // aceSpades
            // 
            this.aceSpades.Image = ((System.Drawing.Image)(resources.GetObject("aceSpades.Image")));
            this.aceSpades.Location = new System.Drawing.Point(349, 73);
            this.aceSpades.Name = "aceSpades";
            this.aceSpades.Size = new System.Drawing.Size(154, 220);
            this.aceSpades.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.aceSpades.TabIndex = 2;
            this.aceSpades.TabStop = false;
            this.aceSpades.Click += new System.EventHandler(this.aceSpades_Click);
            // 
            // joker
            // 
            this.joker.Image = ((System.Drawing.Image)(resources.GetObject("joker.Image")));
            this.joker.Location = new System.Drawing.Point(523, 73);
            this.joker.Name = "joker";
            this.joker.Size = new System.Drawing.Size(151, 221);
            this.joker.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.joker.TabIndex = 3;
            this.joker.TabStop = false;
            this.joker.Click += new System.EventHandler(this.joker_Click);
            // 
            // kingSpades
            // 
            this.kingSpades.Image = ((System.Drawing.Image)(resources.GetObject("kingSpades.Image")));
            this.kingSpades.Location = new System.Drawing.Point(691, 74);
            this.kingSpades.Name = "kingSpades";
            this.kingSpades.Size = new System.Drawing.Size(151, 220);
            this.kingSpades.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.kingSpades.TabIndex = 4;
            this.kingSpades.TabStop = false;
            this.kingSpades.Click += new System.EventHandler(this.kingSpades_Click);
            // 
            // instructionsButton
            // 
            this.instructionsButton.AutoSize = true;
            this.instructionsButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.instructionsButton.Location = new System.Drawing.Point(330, 21);
            this.instructionsButton.Name = "instructionsButton";
            this.instructionsButton.Size = new System.Drawing.Size(199, 18);
            this.instructionsButton.TabIndex = 5;
            this.instructionsButton.Text = "Click a Card to See Its Name";
            // 
            // cardName
            // 
            this.cardName.BackColor = System.Drawing.SystemColors.Window;
            this.cardName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.cardName.Location = new System.Drawing.Point(196, 335);
            this.cardName.Name = "cardName";
            this.cardName.Size = new System.Drawing.Size(478, 23);
            this.cardName.TabIndex = 6;
            this.cardName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(860, 392);
            this.Controls.Add(this.cardName);
            this.Controls.Add(this.instructionsButton);
            this.Controls.Add(this.kingSpades);
            this.Controls.Add(this.joker);
            this.Controls.Add(this.aceSpades);
            this.Controls.Add(this.eightDiamonds);
            this.Controls.Add(this.twoClubs);
            this.Name = "Form1";
            this.Text = "Card Identifer";
            ((System.ComponentModel.ISupportInitialize)(this.twoClubs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eightDiamonds)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aceSpades)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.joker)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kingSpades)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox twoClubs;
        private System.Windows.Forms.PictureBox eightDiamonds;
        private System.Windows.Forms.PictureBox aceSpades;
        private System.Windows.Forms.PictureBox joker;
        private System.Windows.Forms.PictureBox kingSpades;
        private System.Windows.Forms.Label instructionsButton;
        private System.Windows.Forms.Label cardName;
    }
}

