﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Card_Identifer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void twoClubs_Click(object sender, EventArgs e)
        {
            cardName.Text = "Two of Clubs";
        }

        private void eightDiamonds_Click(object sender, EventArgs e)
        {
            cardName.Text = "Eight of Diamonds";
        }

        private void aceSpades_Click(object sender, EventArgs e)
        {
            cardName.Text = "Ace of Spades";
        }

        private void joker_Click(object sender, EventArgs e)
        {
            cardName.Text = "Joker";
        }

        private void kingSpades_Click(object sender, EventArgs e)
        {
            cardName.Text = "King of Spades";
        }
    }
}
