﻿/**
* 02/15/2018
* CSC 153
* Anthony O'Brien
* Name formatting program that takes users name and displays different formats.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Name_Formatter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void formatButton_Click(object sender, EventArgs e)
        {
            //User variables
            format1TextBox.Text = titleTextBox.Text + " " + firstTextBox.Text + " " + middleTextBox.Text + " " + lastTextBox.Text;
            format2TextBox.Text = firstTextBox.Text + " " + middleTextBox.Text + " " + lastTextBox.Text;
            format3TextBox.Text = firstTextBox.Text + " " + lastTextBox.Text;
            format4TextBox.Text = lastTextBox.Text + "," + " " + firstTextBox.Text + " " + middleTextBox.Text + "," + " " + titleTextBox.Text;
            format5TextBox.Text = lastTextBox.Text + "," + " " + firstTextBox.Text + " " + middleTextBox.Text;
            format6TextBox.Text = lastTextBox.Text + "," + " " + firstTextBox.Text;
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            format1TextBox.Text = "";
            format2TextBox.Text = "";
            format3TextBox.Text = "";
            format4TextBox.Text = "";
            format5TextBox.Text = "";
            format6TextBox.Text = "";
            firstTextBox.Text = "";
            middleTextBox.Text = "";
            lastTextBox.Text = "";
            titleTextBox.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
