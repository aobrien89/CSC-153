﻿/**
* 02/15/2018
* CSC 153
* Anthony O'Brien
* Name formatting program that takes users name and displays different formats.
*/
namespace Name_Formatter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.firstTextBox = new System.Windows.Forms.TextBox();
            this.middleTextBox = new System.Windows.Forms.TextBox();
            this.lastTextBox = new System.Windows.Forms.TextBox();
            this.titleTextBox = new System.Windows.Forms.TextBox();
            this.titleLabel = new System.Windows.Forms.Label();
            this.lastLabel = new System.Windows.Forms.Label();
            this.middleLabel = new System.Windows.Forms.Label();
            this.firstnameLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.format6TextBox = new System.Windows.Forms.Label();
            this.format5TextBox = new System.Windows.Forms.Label();
            this.format4TextBox = new System.Windows.Forms.Label();
            this.format3TextBox = new System.Windows.Forms.Label();
            this.format2TextBox = new System.Windows.Forms.Label();
            this.format1TextBox = new System.Windows.Forms.Label();
            this.formatButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.firstTextBox);
            this.groupBox1.Controls.Add(this.middleTextBox);
            this.groupBox1.Controls.Add(this.lastTextBox);
            this.groupBox1.Controls.Add(this.titleTextBox);
            this.groupBox1.Controls.Add(this.titleLabel);
            this.groupBox1.Controls.Add(this.lastLabel);
            this.groupBox1.Controls.Add(this.middleLabel);
            this.groupBox1.Controls.Add(this.firstnameLabel);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(209, 145);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Name";
            // 
            // firstTextBox
            // 
            this.firstTextBox.Location = new System.Drawing.Point(97, 38);
            this.firstTextBox.Name = "firstTextBox";
            this.firstTextBox.Size = new System.Drawing.Size(100, 20);
            this.firstTextBox.TabIndex = 1;
            // 
            // middleTextBox
            // 
            this.middleTextBox.Location = new System.Drawing.Point(97, 62);
            this.middleTextBox.Name = "middleTextBox";
            this.middleTextBox.Size = new System.Drawing.Size(100, 20);
            this.middleTextBox.TabIndex = 2;
            // 
            // lastTextBox
            // 
            this.lastTextBox.Location = new System.Drawing.Point(97, 87);
            this.lastTextBox.Name = "lastTextBox";
            this.lastTextBox.Size = new System.Drawing.Size(100, 20);
            this.lastTextBox.TabIndex = 3;
            // 
            // titleTextBox
            // 
            this.titleTextBox.Location = new System.Drawing.Point(97, 115);
            this.titleTextBox.Name = "titleTextBox";
            this.titleTextBox.Size = new System.Drawing.Size(100, 20);
            this.titleTextBox.TabIndex = 4;
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Location = new System.Drawing.Point(11, 118);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(30, 13);
            this.titleLabel.TabIndex = 4;
            this.titleLabel.Text = "Title:";
            // 
            // lastLabel
            // 
            this.lastLabel.AutoSize = true;
            this.lastLabel.Location = new System.Drawing.Point(11, 90);
            this.lastLabel.Name = "lastLabel";
            this.lastLabel.Size = new System.Drawing.Size(59, 13);
            this.lastLabel.TabIndex = 3;
            this.lastLabel.Text = "Last name:";
            // 
            // middleLabel
            // 
            this.middleLabel.AutoSize = true;
            this.middleLabel.Location = new System.Drawing.Point(11, 65);
            this.middleLabel.Name = "middleLabel";
            this.middleLabel.Size = new System.Drawing.Size(70, 13);
            this.middleLabel.TabIndex = 2;
            this.middleLabel.Text = "Middle name:";
            // 
            // firstnameLabel
            // 
            this.firstnameLabel.AutoSize = true;
            this.firstnameLabel.Location = new System.Drawing.Point(11, 41);
            this.firstnameLabel.Name = "firstnameLabel";
            this.firstnameLabel.Size = new System.Drawing.Size(58, 13);
            this.firstnameLabel.TabIndex = 1;
            this.firstnameLabel.Text = "First name:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(161, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter your name to be formatted.";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.format6TextBox);
            this.groupBox2.Controls.Add(this.format5TextBox);
            this.groupBox2.Controls.Add(this.format4TextBox);
            this.groupBox2.Controls.Add(this.format3TextBox);
            this.groupBox2.Controls.Add(this.format2TextBox);
            this.groupBox2.Controls.Add(this.format1TextBox);
            this.groupBox2.Location = new System.Drawing.Point(12, 163);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(209, 244);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Format";
            // 
            // format6TextBox
            // 
            this.format6TextBox.BackColor = System.Drawing.SystemColors.Window;
            this.format6TextBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.format6TextBox.Location = new System.Drawing.Point(6, 189);
            this.format6TextBox.Name = "format6TextBox";
            this.format6TextBox.Size = new System.Drawing.Size(173, 23);
            this.format6TextBox.TabIndex = 6;
            this.format6TextBox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // format5TextBox
            // 
            this.format5TextBox.BackColor = System.Drawing.SystemColors.Window;
            this.format5TextBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.format5TextBox.Location = new System.Drawing.Point(6, 156);
            this.format5TextBox.Name = "format5TextBox";
            this.format5TextBox.Size = new System.Drawing.Size(173, 23);
            this.format5TextBox.TabIndex = 5;
            this.format5TextBox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // format4TextBox
            // 
            this.format4TextBox.BackColor = System.Drawing.SystemColors.Window;
            this.format4TextBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.format4TextBox.Location = new System.Drawing.Point(6, 124);
            this.format4TextBox.Name = "format4TextBox";
            this.format4TextBox.Size = new System.Drawing.Size(173, 23);
            this.format4TextBox.TabIndex = 4;
            this.format4TextBox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // format3TextBox
            // 
            this.format3TextBox.BackColor = System.Drawing.SystemColors.Window;
            this.format3TextBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.format3TextBox.Location = new System.Drawing.Point(6, 92);
            this.format3TextBox.Name = "format3TextBox";
            this.format3TextBox.Size = new System.Drawing.Size(173, 23);
            this.format3TextBox.TabIndex = 3;
            this.format3TextBox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // format2TextBox
            // 
            this.format2TextBox.BackColor = System.Drawing.SystemColors.Window;
            this.format2TextBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.format2TextBox.Location = new System.Drawing.Point(6, 59);
            this.format2TextBox.Name = "format2TextBox";
            this.format2TextBox.Size = new System.Drawing.Size(173, 23);
            this.format2TextBox.TabIndex = 2;
            this.format2TextBox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // format1TextBox
            // 
            this.format1TextBox.BackColor = System.Drawing.SystemColors.Window;
            this.format1TextBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.format1TextBox.Location = new System.Drawing.Point(6, 25);
            this.format1TextBox.Name = "format1TextBox";
            this.format1TextBox.Size = new System.Drawing.Size(173, 23);
            this.format1TextBox.TabIndex = 1;
            this.format1TextBox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // formatButton
            // 
            this.formatButton.Location = new System.Drawing.Point(7, 427);
            this.formatButton.Name = "formatButton";
            this.formatButton.Size = new System.Drawing.Size(75, 23);
            this.formatButton.TabIndex = 1;
            this.formatButton.Text = "Format";
            this.formatButton.UseVisualStyleBackColor = true;
            this.formatButton.Click += new System.EventHandler(this.formatButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(88, 427);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 2;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(169, 427);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 3;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(259, 470);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.formatButton);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Text = "Name Formatter";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox firstTextBox;
        private System.Windows.Forms.TextBox middleTextBox;
        private System.Windows.Forms.TextBox lastTextBox;
        private System.Windows.Forms.TextBox titleTextBox;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.Label lastLabel;
        private System.Windows.Forms.Label middleLabel;
        private System.Windows.Forms.Label firstnameLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label format6TextBox;
        private System.Windows.Forms.Label format5TextBox;
        private System.Windows.Forms.Label format4TextBox;
        private System.Windows.Forms.Label format3TextBox;
        private System.Windows.Forms.Label format2TextBox;
        private System.Windows.Forms.Label format1TextBox;
        private System.Windows.Forms.Button formatButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
    }
}

