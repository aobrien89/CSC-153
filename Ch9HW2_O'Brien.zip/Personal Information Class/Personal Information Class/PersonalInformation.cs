﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Personal_Information_Class
{
    class PersonalInformation
    {
        private string _name;
        private string _address;
        private string _age;
        private string _phone;

        public PersonalInformation()
        {
            _name = " ";
            _address = " ";
            _age = " ";
            _phone = " ";
        }
        public PersonalInformation(string Name, string Address, string Age, string Phone)
        {
            _name = Name;
            _address = Address;
            _age = Age;
            _phone = Phone;
        }
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        public string Address
        {
            get { return _address; }
            set { _address = value; }
        }
        public string Age
        {
            get { return _age; }
            set { _age = value; }
        }
        public string Phone
        {
            get { return _phone; }
            set { _phone = value; }
        }
    }
}
