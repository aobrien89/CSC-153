﻿/**
* 05/12/2018
* CSC 153
* Anthony O'Brien
* Further demostration of classses. This program stores personal information.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Personal_Information_Class
{
    public partial class Form1 : Form
    {
        List<PersonalInformation> infoList = new List<PersonalInformation>();

        PersonalInformation myInfo = new PersonalInformation("Anthony", "123 Fake St", "28", "228-256-6584");
        PersonalInformation friendInfo = new PersonalInformation("Jeff", "124 Fake St", "30", "228-256-7409");
        PersonalInformation familyInfo = new PersonalInformation("Ted", "125 Fake St", "56", "228-256-8523");

        public Form1()
        {
            InitializeComponent();
        }

        private void infoListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            infoList.Add(myInfo);
            infoList.Add(friendInfo);
            infoList.Add(familyInfo);

            int index = infoListBox.SelectedIndex;

            MessageBox.Show("Name: " + infoList[index].Name.ToString() + "\n" + "Address: " + infoList[index].Address.ToString() + "\n"
                + "Age: " + infoList[index].Age.ToString() + "\n" + "Phone Number: " + infoList[index].Phone.ToString());
        }

        private void loadButton_Click(object sender, EventArgs e)
        {
            infoListBox.Items.Add(myInfo.Name);
            infoListBox.Items.Add(friendInfo.Name);
            infoListBox.Items.Add(familyInfo.Name);
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
