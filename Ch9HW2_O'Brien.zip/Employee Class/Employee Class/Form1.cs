﻿/**
* 05/12/2018
* CSC 153
* Anthony O'Brien
* This program stores Employee info and displays it when selected from the listbox
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Employee_Class
{
    public partial class Form1 : Form
    {
        List<Employee> employeeList = new List<Employee>();

        Employee employee1 = new Employee("Susan Meyers", "47899", "Accounting", "Vice President");
        Employee employee2 = new Employee("Mark Jones", "39119", "IT", "Programmer");
        Employee employee3 = new Employee("Joy Rogers", "81774", "Manufacturing", "Engineer");

        public Form1()
        {
            InitializeComponent();
        }
        private void employeeListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            employeeList.Add(employee1);
            employeeList.Add(employee2);
            employeeList.Add(employee3);

            int index = employeeListBox.SelectedIndex;

            MessageBox.Show("Name: " + employeeList[index].Name.ToString() + "\n" + "ID Number: " + employeeList[index].IdNumber.ToString()
                + "\n" + "Department: " + employeeList[index].Department.ToString() + "\n" + "Position: " + employeeList[index].Position.ToString());
        }
        private void loadButton_Click(object sender, EventArgs e)
        {
            employeeListBox.Items.Add(employee1.Name);
            employeeListBox.Items.Add(employee2.Name);
            employeeListBox.Items.Add(employee3.Name);
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
