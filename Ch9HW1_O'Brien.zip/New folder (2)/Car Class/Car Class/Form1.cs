﻿/**
* 05/11/2018
* CSC 153
* Anthony O'Brien
* Creates a Car Class and uses the object myCar to accelerate and decelerate.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Car_Class
{
    public partial class Form1 : Form
    {

        Car myCar = new Car();


        public Form1()
        {
            myCar = new Car();

            InitializeComponent();
        }

        private void GetCarData(Car mycar)
        {
             myCar.Make = makeTextBox.Text;

             myCar.Year = int.Parse(yearTextBox.Text);

             myCar.Speed = int.Parse(speedTextBox.Text);
        }
        private void accelerateButton_Click(object sender, EventArgs e)
        {
            GetCarData(myCar);
            myCar.AccSpeed();
            speedTextBox.Text = myCar.Speed.ToString();
        }

        private void brakeButton_Click(object sender, EventArgs e)
        {
            GetCarData(myCar);
            myCar.DecSpeed();
            speedTextBox.Text = myCar.Speed.ToString();
        }
    }
}