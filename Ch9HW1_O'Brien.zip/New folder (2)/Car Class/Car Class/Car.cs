﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Car_Class
{
    class Car
    {
        private int _year;
        private string _make;
        private int _speed;

        public Car()
        {
            _year = 0;
            _make = " ";
            _speed = 0;
        }
        public string Make
        {
            get { return _make; }
            set { _make = value; }
        }

        public int Year
        {
            get { return _year; }
            set { _year = value; }
        }

        public int Speed
        {
            get { return _speed; }
            set { _speed = value; }
        }

        public int AccSpeed()
        {
            Speed = Speed + 5;
            return Speed;
        }

        public int DecSpeed()
        {
            Speed = Speed - 5;
            return Speed;
        }
    }
}
