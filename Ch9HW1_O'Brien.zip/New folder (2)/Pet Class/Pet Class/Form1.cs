﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pet_Class
{
    public partial class Form1 : Form
    {
        List<Pet> petList = new List<Pet>();

        public Form1()
        {
            InitializeComponent();
        }
        private void GetPetData(Pet myPet)
        {
            myPet.Name = nameTextBox.Text;
            myPet.Type = typeTextBox.Text;
            myPet.Age = ageTextBox.Text;
            
            
        }

        private void addPetButton_Click(object sender, EventArgs e)
        {
            Pet myPet = new Pet();

            GetPetData(myPet);

            petList.Add(myPet);

            petListBox.Items.Add(myPet.Name);

            nameTextBox.Clear();
            ageTextBox.Clear();
            typeTextBox.Clear();
            nameTextBox.Focus();
        }

        private void petListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = petListBox.SelectedIndex;

            MessageBox.Show("Pet name: " + petList[index].Name.ToString() + "\n" + "Pet Type: " + petList[index].Type.ToString() + "\n" + "Pet Age: " +
                petList[index].Age.ToString());

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
