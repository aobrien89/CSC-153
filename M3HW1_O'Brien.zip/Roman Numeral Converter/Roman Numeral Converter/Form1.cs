﻿/**
* 02/27/2018
* CSC 153
* Anthony O'Brien
* Converts an inputed number of 1-10 to Roman Numeral.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Roman_Numeral_Converter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void convertButton_Click(object sender, EventArgs e)
        {
            int number;      //Hold number to be converted
            int.TryParse(numberTextBox.Text, out number);
            switch (number)
            {
                case 1:
                    romanLabel.Text = "I";
                    break;
                case 2:
                    romanLabel.Text = "II";
                    break;
                case 3:
                    romanLabel.Text = "III";
                    break;
                case 4:
                    romanLabel.Text = "IV";
                    break;
                case 5:
                    romanLabel.Text = "V";
                    break;
                case 6:
                    romanLabel.Text = "VI";
                    break;
                case 7:
                    romanLabel.Text = "VII";
                    break;
                case 8:
                    romanLabel.Text = "VIII";
                    break;
                case 9:
                    romanLabel.Text = "IX";
                    break;
                case 10:
                    romanLabel.Text = "x";
                    break;
                default:
                    MessageBox.Show("Error: Invalid number");
                    break;
            }
            
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            numberTextBox.Text = "";
            romanLabel.Text = "";
            numberTextBox.Focus();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
